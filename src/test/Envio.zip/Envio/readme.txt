201710_CSOF5101_01 - CONCEP. AVAN. DE INGENI. SOFTW
Tarea 1 psp0
Daniel Melgarejo Rodriguez
6/2/2017 9:40
Para ejecutar el programa debe tener correctamente configurado el entorno de Java, en caso contrario por favor instale Java jre y asegurese de que la carpeta bin este en las variables de entorno del sistema.
Inicie una consola de comandos (cmd) y opcionalmente ubiquese en el directorio que contiene el archivo psp0.jar (ubicado en la carpeta src del este zip) para ejecutarlo debe ingresar el siguiente comando:
	java -jar RUTA_A_PROGRAMA/src/psp0.jar RUTA_A_ARCHIVO/archivo.txt
En donde RUTA_A_PROGRAMA indica la ruta en donde extrajo el zip y RUTA_A_ARCHIVO donde tiene el archivo con los datos a procesar. Ejemplo:
	java -jar Desktop/psp0.jar Desktop/datos.txt
En caso de no poder ejecuar el programa por linea de comandos puede cargar el proyecto en un ide y reemplazar la variable path de linea 10 en la clase Main por la ruta al archivo con los datos.